package com.SinglyCircularLL;

public class SinglyCircularLLMain {

	public static void main(String[] args) {
		
		SinglyCircularLL l = new SinglyCircularLL();
		
		l.addAtLast(10);
		l.addAtLast(20);
		l.addAtLast(30);
		l.addAtLast(40);
		l.addAtLast(50);
		
		l.display();
		

	}

}
